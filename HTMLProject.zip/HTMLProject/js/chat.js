$('body').on('click','.send',function(event){
		var data=$('#textArea').val();
		addDataToScreen(data,'self');
});

$('body').on('keypress','#textArea',function(event){
	if(event.keyCode===13)
	{
		var data=$('#textArea').val();
		if(data.trim()!=""&&typeof data !='undefined')
		{
		addDataToScreen(data,'self');
		}
	}
});

function sendOtherUser(data)
{
	addDataToScreen(data,'other');
}

function addDataToScreen(data,userClass)
{
		var element=$('<li></li>');
		$(element).addClass(userClass);
		var divElementMsg=$('<div></div>');
		$(divElementMsg).addClass('msg');
		var divElement=$('<div></div>');
		$(divElement).addClass('user');
		var paragraph=$('<p></p>');
		var time=$('<time></time>');
		var d=new Date();
		time.append(d.getDate()+"/"+d.getMonth()+"/"+d.getFullYear());
		paragraph.append(data);
		divElementMsg.append(divElement);
		divElementMsg.append(paragraph);
		divElementMsg.append(time);
		element.append(divElementMsg);
		$('.chat').append(element);
		$('#textArea').val("");
}